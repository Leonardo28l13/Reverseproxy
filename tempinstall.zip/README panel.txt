Before you can start using this addon, you have to make sure you have Blueprint installed. You can find more information at https://blueprint.zip

If you have Blueprint installed, place the "reverseproxy.blueprint" in the home folder of your Pterodactyl installation (probably "/var/www/pterodactyl").

After that, run the following commands to complete the addon installation:
    blueprint -install reverseproxy
